<div>
    <?php $__env->startSection('title', __('Pesan Ambulance')); ?>
    <!-- Contact 1 - Bootstrap Brain Component -->
    <section class="bg-light py-3 py-md-5">
        <div class="container">
            <div class="row justify-content-md-center">
                <div class="col-12 col-md-10 col-lg-8 col-xl-7 col-xxl-6">
                    <h2 class="mb-4 display-5 text-center">
                        Pesan Ambulance
                    </h2>
                    <p class="text-secondary mb-5 text-center">
                        Halaman untuk memesan e-ambulance - SIP Puskesmas Tanggetada.
                    </p>

                    <hr class="w-50 mx-auto mb-5 mb-xl-9 border-dark-subtle">
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row justify-content-lg-center">
                <div class="col-12 col-lg-12">
                    <?php if($belumLogin == false): ?>
                    <div class="bg-white border rounded shadow-sm overflow-hidden mb-2">
                        <?php if(auth()->guard()->guest()): ?>
                        <div class="text-center p-5 m-2 d-flex justify-content-center ">
                            <div class="card m-2 bg-warning" style="width: 18rem;">
                                <div class="card-body">
                                    <h5 class="card-title">Sudah Memiliki Akun?</h5> <br>
                                    <a href="/login" class="btn btn-primary">Login</a>
                                </div>
                            </div>

                            <div class="card m-2 bg-danger" style="width: 18rem;">
                                <div class="card-body">
                                    <h5 class="card-title">Belum Memiliki Akun?</h5> <br>
                                    <a href="#" wire:click.prevent="register" class="btn btn-success">Register</a>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php else: ?>
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="row">
                                
                                
                                
                                
                                <form wire:submit.prevent="submit">
                                    <?php echo csrf_field(); ?> <div class="row">
                                        <div class="col-6 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                            <div class="form-group mb-2">
                                                <label for="nama">Nama</label>
                                                <input wire:model="name" type="text" class="form-control" id="nama" placeholder="Masukkan Nama Anda">
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="no_telp">No Telp</label>
                                                <input wire:model="no_telp" type="text" class="form-control" id="no_telp" placeholder="Masukkan nomor telepon">
                                                <?php $__errorArgs = ['no_telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                            <div class="form-group mb-2">
                                                <label for="email">Email</label>
                                                <input wire:model="email" type="email" class="form-control" id="email" placeholder="Masukkan Email">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="password">Password</label>
                                                <input wire:model="password" type="password" class="form-control" id="password" placeholder="Masukkan Password">
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    
                                    

                                    <div class="row" wire:ignore.self>
                                        <div class="col-6 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                            <div class="form-group mb-2">
                                                <label for="nama_pasien">Nama Pasien</label>
                                                <input wire:model="nama_pasien" type="text" class="form-control" id="nama_pasien" placeholder="Masukkan Nama Pasien">
                                                <?php $__errorArgs = ['nama_pasien'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group mb-2">
                                                <label for="keterangan_pasien">Deskripsi Pasien</label>
                                                <textarea wire:model="keterangan_pasien" class="form-control" id="keterangan_pasien" rows="3" placeholder="Masukkan Deskripsi Pasien"></textarea>
                                                <?php $__errorArgs = ['keterangan_pasien'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group mb-2">
                                                <label for="kategori_id">Kategori</label>
                                                <select wire:model="kategori_id" class="form-control" id="kategori_id">
                                                    <option value="">Pilih Kategori</option>
                                                    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['kategori_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group mb-2">
                                                <label for="rumahsakit_id">Rumah Sakit</label>
                                                <select wire:model="rumahsakit_id" class="form-control" id="rumahsakit_id">
                                                    <option value="">Pilih Rumah Sakit</option>
                                                    <?php $__currentLoopData = $rumahsakits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($rs->id); ?>"><?php echo e($rs->nama); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['rumahsakit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            </div>
                                        </div>
                                        <div class="col-6 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                                            <div class="form-group mb-2">
                                                <label for="alamat_jemput">Alamat Lengkap</label>
                                                <textarea wire:model="alamat_jemput" class="form-control" id="alamat_jemput" rows="3" placeholder="Masukkan Alamat Lengkap Pengantaran"></textarea>
                                                <?php $__errorArgs = ['alamat_jemput'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            

                                            <div class="form-group">
                                                <label>Latitude<span class="form-label">*</span></label>
                                                <input wire:model="latitude" id="latitude" class="form-control <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="latitude">
                                                <small class="text-muted">*Tambahkan angka 0 di akhir </small>
                                                <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label>Longitude<span class="form-label">*</span></label>
                                                <input wire:model="longitude" id="longitude" class="form-control <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="longitude">
                                                <small class="text-muted">*Tambahkan angka 0 di akhir </small>
                                                <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group mb-2">
                                                <button type="button" class="btn btn-sm btn-block btn-primary" onclick="getLocation()">
                                                    <i class="fas fa-map-marker-alt"></i>
                                                    Get Long Lat</button>
                                            </div>

                                        </div>
                                        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                            <div class="d-flex justify-content-end">
                                                <button class="btn btn-sm btn-primary" type="submit">
                                                    <i class="fas fa-check"></i>
                                                    Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
    </section>
    <script>
        function getLocation() {
            var latitudeInput = document.getElementById("latitude");
            var longitudeInput = document.getElementById("longitude");

            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    latitudeInput.value = position.coords.latitude;
                    longitudeInput.value = position.coords.longitude;
                    Livewire.emit('get-location', position.coords.latitude, position.coords.longitude);
                });
            } else {
                alert('Geolocation is not supported by this browser.');
            }
        }

    </script>
</div>
<?php /**PATH C:\laragon\www\ambulance\resources\views/livewire/user/pesan.blade.php ENDPATH**/ ?>