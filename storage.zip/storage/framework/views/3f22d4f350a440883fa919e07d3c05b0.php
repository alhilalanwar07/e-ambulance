<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php if (! empty(trim($__env->yieldContent('title')))): ?> <?php echo $__env->yieldContent('title'); ?> | <?php endif; ?>
        <?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <?php echo \Livewire\Livewire::styles(); ?>

    <link rel="shortcut icon" href="<?php echo e(url('/')); ?>/assets/img/puskesmas_small.png">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,400;0,500;0,700;0,900;1,400;1,500;1,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/plugins/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/plugins/feather/feather.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/plugins/icons/flags/flags.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/plugins/fontawesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/plugins/fontawesome/css/all.min.css">
    

    <style>
        .gradient-text {
            /* Menerapkan efek gradien ke teks */
            background: -webkit-linear-gradient(90deg, #00C9FF, #92FE9D);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;

            /* Opsi tambahan untuk mendukung browser lain */
            background: linear-gradient(90deg, #00C9FF, #92FE9D);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;

            /* buat text mengampung bayangan */
            -webkit-text-stroke: 0.5px rgba(255, 255, 255, 255);
            /* stroke keluar text */
            text-stroke: 0.5px rgba(255, 255, 255, 255);

            /* Menambahkan bayangan di belakang teks */
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
        }

    </style>
</head>

<body>
    <div class="main">

        

        <nav class="navbar navbar-expand-lg navbar-light text-white fw-bold sticky-top" style="background-image: linear-gradient(90deg, #00C9FF 0%, #92FE9D 100%);">

            <div class="container-fluid">
                <a class="navbar-brand" href="#">
                    <img src="<?php echo e(url('/')); ?>/assets/img/puskesmas_tanggetada.png" alt="Logo" width="150" class="d-inline-block align-text-top">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Request::is('/') ? 'active' : ''); ?>" aria-current="page" href="/">Beranda</a>
                        </li>
                        <?php if(Auth::check()): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Request::is('riwayat') ? 'active' : ''); ?>" href="/riwayat">Riwayat</a>
                        </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Request::is('kontak') ? 'active' : ''); ?>" href="/kontak">Kontak</a>
                        </li>
                        
                        <?php if(Auth::check()): ?>
                        <li class="nav-item">
                            <a href="#" class="nav-link text-danger" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                Logout
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                        <?php endif; ?>

                    </ul>
                    <form class="d-flex">
                        <?php if(Auth::check()): ?>
                        <div class="dropdown">
                            <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                                <img src="https://ui-avatars.com/api/?name=<?php echo e(Auth::user()->name); ?>" alt="" width="32" height="32" class="rounded-circle me-2">
                                <?php echo e(Auth::user()->name); ?>

                            </a>
                            <ul class="dropdown-menu dropdown-menu-end text-small shadow" aria-labelledby="dropdownUser1">
                                <li>
                                    <button class="dropdown-item nav-link text-danger" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        Logout
                                    </button>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </li>
                            </ul>
                        </div>
                        <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary me-2">Login</a>
                        
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </nav>

        
        <?php echo e($slot); ?>

        
        <footer class="footer sticky-bottom shadow-md p-2 fw-bold" style="background-image: linear-gradient(90deg, #00C9FF 0%, #92FE9D 100%);">
            <p class="text-center my-2">Copyright © <?php echo e(date('Y')); ?>

                Puskesmas Tanggetada. All rights reserved.</p>
        </footer>
        
    </div>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script type="module">
        const addModal = new bootstrap.Modal('#createDataModal');
        const editModal = new bootstrap.Modal('#updateDataModal');
        window.addEventListener('closeModal', () => {
            addModal.hide();
            editModal.hide();
        })
    </script>
    <script src="<?php echo e(url('/')); ?>/assets/js/jquery-3.6.0.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/js/feather.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/plugins/apexchart/apexcharts.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/assets/plugins/apexchart/chart-data.js"></script>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\ambulance\resources\views/layouts/user.blade.php ENDPATH**/ ?>