<?php

namespace App\Http\Livewire\User;

use Livewire\Component;

class Kontak extends Component
{
    public function render()
    {
        return view('livewire.user.kontak')->layout('layouts.user');
    }
}
