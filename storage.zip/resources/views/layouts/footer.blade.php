<!-- jquery latest version -->
<script src="{{ url('/') }}/assets/js/vendor/jquery-2.2.4.min.js"></script>
<!-- bootstrap 4 js -->
<script src="{{ url('/') }}/assets/js/popper.min.js"></script>
<script src="{{ url('/') }}/assets/js/bootstrap.min.js"></script>
<script src="{{ url('/') }}/assets/js/owl.carousel.min.js"></script>
<script src="{{ url('/') }}/assets/js/metisMenu.min.js"></script>
<script src="{{ url('/') }}/assets/js/jquery.slimscroll.min.js"></script>
<script src="{{ url('/') }}/assets/js/jquery.slicknav.min.js"></script>

<!-- others plugins -->
<script src="{{ url('/') }}/assets/js/plugins.js"></script>
<script src="{{ url('/') }}/assets/js/scripts.js"></script>

</body>

</html>
