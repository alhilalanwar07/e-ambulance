## Laravel 10 template admin with livewire.
