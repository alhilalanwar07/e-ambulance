<?php return array (
  'kategoris' => 'App\\Http\\Livewire\\Kategoris',
  'pelanggans' => 'App\\Http\\Livewire\\Pelanggans',
  'pesanans' => 'App\\Http\\Livewire\\Pesanans',
  'province-and-city' => 'App\\Http\\Livewire\\ProvinceAndCity',
  'rumahsakits' => 'App\\Http\\Livewire\\Rumahsakits',
  'supirs' => 'App\\Http\\Livewire\\Supirs',
  'user.detail' => 'App\\Http\\Livewire\\User\\Detail',
  'user.home' => 'App\\Http\\Livewire\\User\\Home',
  'user.kontak' => 'App\\Http\\Livewire\\User\\Kontak',
  'user.pesan' => 'App\\Http\\Livewire\\User\\Pesan',
  'user.riwayat' => 'App\\Http\\Livewire\\User\\Riwayat',
  'users' => 'App\\Http\\Livewire\\Users',
);